import React from 'react';
import './app.css';
import Habit from './components/habit';

function App() {
  return <Habit />;
}
export default App;
